import sys
sys.path.append("D:/dev/myplugin/src")
sys.path.append("D:/dev/")
print("added path")
